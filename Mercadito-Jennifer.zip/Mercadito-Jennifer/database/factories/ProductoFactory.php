<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ProductoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'codigo'=>$this->faker->randomElement($array = array ('JL','AJ','LM','ML')).$this->faker->numerify('-####'),
            'nombre'=>$this->faker->randomElement($array = array ('Frijoles','Azucar','Huevos', 'Arroz',  
                            'Jabón', 'Aceite', 'Manteca', 'Cereal', 'Avena', 'Mantequilla', 'Queso')), 
            'precio_venta'=>$this->faker->randomFloat($nbMaxDecimals = 2, $min = 20, $max = 90),
            'precio_compra'=>$this->faker->randomFloat($nbMaxDecimals = 2, $min = 15, $max = 70),
            'descripcion'=>$this->faker->text($maxNbChars = 35)
        ];
    }
}
