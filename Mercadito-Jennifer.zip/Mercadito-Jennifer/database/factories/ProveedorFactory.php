<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ProveedorFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            
            'nombres'=> $this->faker->firstName(),
            'apellidos' => $this->faker->lastName(),
            'identidad' =>$this->faker->numberBetween(0, 1 ). $this->faker->numberBetween(0, 8 ). $this
              ->faker->numberBetween(0, 2). $this->faker->numberBetween(0, 8 ). '-'. $this->faker
              ->numerify('19##'). $this->faker->numerify('-####'),
            'fecha_nacimiento' =>$this->faker->date($format = 'Y-m-d', $max = '2000-12-31', $min = '1900-12-31'),
            'direccion'=>$this->faker->address(),
            'descripcion'=>$this->faker->text($maxNbChars = 45),
            'sexo'=>$this->faker->randomElement($array = array ('Masculino','Femenino'))
        ];
    }
}
