<?php

namespace Database\Seeders;

use App\Models\Cliente;
use Illuminate\Database\Seeder;

class ClienteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //aca se escribe esa linea de codigo para crear los datos 
        //crea 50 datos en la tabla 
        
       Cliente::factory(500)->create();
    }
}
