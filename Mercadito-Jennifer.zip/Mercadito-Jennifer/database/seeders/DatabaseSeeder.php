<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

         //esta es la segunda manera se debe de crear el seeder para que funcione 
        //manda a llamar a los seeder para llenar la tabla 
         $this->call([
            ClienteSeeder::class, ProveedorSeeder::class, ProductoSeeder::class ]);
    }
}
